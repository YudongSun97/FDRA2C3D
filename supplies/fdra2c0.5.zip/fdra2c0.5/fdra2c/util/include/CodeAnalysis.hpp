#ifndef INCLUDE_UTIL_CODEANALYSIS
#define INCLUDE_UTIL_CODEANALYSIS

#include <sys/time.h>
#include <vector>

namespace util {
  using namespace std;

#ifdef ANALYZE_CODE
# define caprint(...) printf(__VA_ARGS__)
#else
# define caprint(...)
#endif

#define errpr(...) fprintf(stderr, __VA_ARGS__);

  class Timer {
  public:
    static double Et(const timeval& t1, const timeval& t2)
    {
#ifdef ANALYZE_CODE
      static const double us = 1.0e6;
      return (t2.tv_sec*us + t2.tv_usec - t1.tv_sec*us - t1.tv_usec)/us;
#else
      return 0.0;
#endif
    }

    timeval Time()
    {
      timeval t;
#ifdef ANALYZE_CODE
      gettimeofday(&t, 0);
#endif
      return t;
    }

    void Reset(size_t idx)
    {
#ifdef ANALYZE_CODE
      if (idx >= _tv.size()) _tv.resize(idx + 1);
      _tv[idx].tot_et = 0.0;
#endif
    }

    void Tic(size_t idx)
    {
#ifdef ANALYZE_CODE
      if (idx >= _tv.size()) _tv.resize(idx + 1);
      gettimeofday(&_tv[idx].tv, 0);
#endif
    }

    double Toc(size_t idx)
    {
#ifdef ANALYZE_CODE
      if (idx >= _tv.size()) return 0.0;
      timeval t;
      gettimeofday(&t, 0);
      double et = Et(_tv[idx].tv, t);
      _tv[idx].tot_et += et;
      return et;
#else
      return 0.0;
#endif
    }

    double TotEt(size_t idx)
    {
#ifdef ANALYZE_CODE
      if (idx >= _tv.size()) Reset(idx);
      return _tv[idx].tot_et;
#else
      return 0.0;
#endif
    }

  private:
    struct Slot {
      timeval tv;
      double tot_et;
      Slot() : tot_et(0.0) {}
    };

    vector<Slot> _tv;
  };

  namespace Ca {

    util::Timer* GetTimer();

  }

}

/* Some handy debug code:
#include <sys/resource.h>
  static void ReportStuff()
  {
    rusage r;
    getrusage(RUSAGE_SELF, &r);
    errpr("%1.1f %1.1f\n",
          (r.ru_utime.tv_sec*1.0e6 + r.ru_utime.tv_usec)*1.0e-6,
          r.ru_maxrss*1.0e-3);
  }
*/

#endif
