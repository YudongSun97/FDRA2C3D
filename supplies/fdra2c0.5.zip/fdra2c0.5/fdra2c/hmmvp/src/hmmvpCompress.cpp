/* hmmvpCompress creates an H-matrix. Run hmmvpCompress on the command line
   without arguments to see documentation.

   Look for the string DEV in this file to see how to add a new Green's
   function.

   Build as follows. For parallelization by MPI:
     make compress mode=p opt=-O
   For serial with no MPI dependencies:
     make compress mode=s opt=-O
   Edit the top lines of Makefile to profile pointers to LAPACK, BLAS, and
   serial and parallel C++ compilers and a Fortran compiler. */

#include <stdio.h>
#include <math.h>
#include "Mpi.hpp"
#include "KeyValueFile.hpp"
#include "Util.hpp"
#include "CodeAnalysis.hpp"
#include "Hd.hpp"
#include "Compress.hpp"
#include "Help.hpp" // help text
using namespace std;
using namespace hmmvp;
using namespace util;

/* DEV Implement Green's functions here. To add a new Green's function, follow
   these steps:
     
   1. Inherit from ImplGreensFn or one of its descendants.
   2. Add the new string identifier to NewGreensFn().

   You needn't worry about MPI parallelization. Implement your class as though
   this is a serial code. For examples, see the classes that follow. */

class ImplGreensFn : public GreensFn {
public:
  virtual ~ImplGreensFn() {}

  /* DEV Use the key-value file to initialize the Green's function. If
     something in the input is amiss, throw an exception stating the
     problem. */
  virtual void Init(const KeyValueFile* kvf) throw (Exception) = 0;

  /* DEV Return an Hd corresponding to the model discretization. First
     determine the element centers. Then return the result of
     hmmvp::NewHd(). */
  virtual Hd* ComputeHd() = 0;

  /* DEV Compute B(rs,cs). Indexing starts at 1. B is preallocated.
     Return true if all is well; false if there is an error in computing the
     Green's function and you want compression to stop. */
  virtual bool Call(const vector<uint>& rs, const vector<uint>& cs,
                    double* B) = 0;

  /* DEV Optionally do extra tasks, such as computing the boundary
     conditions. The 'Serial' version is called only by the root process and is
     probably what you want. The 'Mpi' version is called by all processes; quite
     likely you have no reason to implement it. */
  virtual void DoExtraTasksSerial() throw (Exception) {}
  virtual void DoExtraTasksMpi()    throw (Exception) {}
};

/* DEV For neatness, you might put your code into a file whose name
   corresponds to the string identifier and include it here. */
#include "GreensFnInverseR.cpp"
#include "GreensFnOkadaRect.cpp"
#include "GreensFnOkadaSubductSymmRectPeriodic.cpp"

ImplGreensFn* NewGreensFn(const string& id, const KeyValueFile* kvf)
  throw (Exception)
{
  ImplGreensFn* gf = NULL;
  /* DEV Add your GF's string identifier here. */
  if (id == "inverse-r") {
    gf = new InverseRGreensFn();
  } else if (id == "okada-rect") {
    gf = new OkadaRectGf();
  } else if (id == "okada-subduct-symm-rect-periodic") {
    gf = new OssrpGf();
  } else {
    throw Exception("No such Green's function string identifier.");
  }
  if (!gf) throw Exception("gf is NULL.");
  try {
    gf->Init(kvf);
    return gf;
  } catch (const Exception& e) {
    delete gf;
    throw e;
  }
}

/* DEV You should not have to modify anything below here. */

namespace {

  void PrintHelp()
  {
    fprintf(stdout, _hmmvpCompress_PrintHelp_text_);
  }
  
  int Finalize(int code)
  {
    mpi::Finalize();
    return code;
  }

  int Error(const string& s, hmmvp::KeyValueFile* kvf)
  {
    fprintf(stderr, "No key %s.\n", s.c_str());
    if (mpi::AmRoot()) hmmvp::DeleteKeyValueFile(kvf);
    return Finalize(-1);
  }

  struct Inputs {
    bool allow_overwrite, do_extra_tasks_only;
    string write_hmat_filename, use_hmat_filename;
    string write_hd_filename, use_hd_filename;
    string greens_fn_name;
    double tol, Bfro;
  };

  int ProcessKvf(hmmvp::KeyValueFile* kvf, Inputs& in)
  {
    double d;
    const string* s;
    bool am_root = mpi::AmRoot();

    in.allow_overwrite = false;
    if (kvf->GetDouble("allow_overwrite", d))
      in.allow_overwrite = (bool) d;
    in.do_extra_tasks_only = false;
    if (kvf->GetDouble("do_extra_tasks_only", d))
      in.do_extra_tasks_only = (bool) d;

    in.write_hmat_filename = "";
    if (!kvf->GetString("write_hmat_filename", s))
      return Error("write_hmat_filename", kvf);
    in.write_hmat_filename = *s;
    if (!in.allow_overwrite &&
        access(in.write_hmat_filename.c_str(), F_OK) == 0) {
      if (am_root)
        fprintf(stderr, "%s exists; won't overwrite.\n",
                in.write_hmat_filename.c_str());
      return Finalize(-1);
    }

    in.use_hd_filename = "";
    in.write_hd_filename = "";
    if (kvf->GetString("use_hd_filename", s)) in.use_hd_filename = *s;
    if (kvf->GetString("write_hd_filename", s)) in.write_hd_filename = *s;
    if (!in.use_hd_filename.empty() && !in.write_hd_filename.empty()) {
      if (am_root)
        fprintf(stderr, "Must provide none or only one of use_hd_filename or "
                "write_hd_filename.");
      return Finalize(-1);
    }
    if (!in.allow_overwrite &&
        access(in.write_hd_filename.c_str(), F_OK) == 0) {
      if (am_root)
        fprintf(stderr, "%s exists; won't overwrite.\n",
                in.write_hd_filename.c_str());
      return Finalize(-1);
    }

    if (!kvf->GetDouble("tol", in.tol)) Error("tol", kvf);

    if (!kvf->GetString("greens_fn", s)) return Error("greens_fn", kvf);
    in.greens_fn_name = *s;

    in.Bfro = -1.0;
    if (kvf->GetDouble("Bfro", in.Bfro) && in.Bfro <= 0.0) {
      if (am_root) fprintf(stderr, "Bfro must be > 0.\n");
      return Finalize(-1);
    }

    in.use_hmat_filename = "";
    if (kvf->GetString("use_hmat_filename", s)) in.use_hmat_filename = *s;
    if (in.use_hmat_filename == in.write_hmat_filename) {
      if (am_root) fprintf(stderr, "use_hmat_filename == write_hd_filename.\n");
      return Finalize(-1);
    }

    return 0;
  }

  void SetBfro(Compressor* c, double in_Bfro)
  {
    if (c->HaveOldHmat())
      c->SetBfroEstimate(c->GetOldHmatBfro());
    else if (in_Bfro > 0.0)
      c->SetBfroEstimate(in_Bfro);
    else
      c->SetBfroEstimate(c->EstimateBfro());
  }

}

int main(int argc, char** argv)
{
  mpi::Init(argc, argv);
  bool am_root = mpi::AmRoot();

  if (argc != 2) {
    if (am_root) PrintHelp();
    return Finalize(-1);
  }

  // Handle key-value file.
  Inputs in;
  hmmvp::KeyValueFile* kvf;
  { kvf = hmmvp::NewKeyValueFile();
    if (!kvf->Read(argv[1])) {
      if (am_root)
        fprintf(stderr, "Failed to read the key-value file %s.\n", argv[1]);
      DeleteKeyValueFile(kvf);
      return Finalize(-1);
    }
    int ret;
    if ((ret = ProcessKvf(kvf, in))) return ret; }

  // Create the Green's function.
  ImplGreensFn* gf = NULL;
  try {
    gf = NewGreensFn(in.greens_fn_name, kvf);
  } catch (const Exception& e) {
    if (am_root)
      fprintf(stderr, "From greens_fn_name = %s comes the exception: %s\n",
              in.greens_fn_name.c_str(), e.GetMsg().c_str());
  }
  DeleteKeyValueFile(kvf);
  if (!gf) return Finalize(-1);
  
  if (am_root) printf("... Doing extra tasks.\n");
  try {
    if (am_root)
      gf->DoExtraTasksSerial();
    gf->DoExtraTasksMpi();
  } catch (const Exception& e) {
    fprintf(stderr, "DoExtraTasks gives the exception: %s.\n",
            e.GetMsg().c_str());
    delete gf;
    return Finalize(-1);
  }
  if (in.do_extra_tasks_only) {
    if (am_root) printf("... Exiting after doing extra tasks only.");
    delete gf;
    return Finalize(0);
  }
  
  // Spatial decomposition.
  hmmvp::Hd* hd = NULL;
  if (am_root) {
    if (!in.use_hd_filename.empty()) {
      try {
        hd = NewHd(in.use_hd_filename);
      } catch (const FileException& e) {
        fprintf(stderr, "Could not read %s.\n", in.use_hd_filename.c_str());
        delete gf;
        return Finalize(-1);
      } catch (const Exception& e) {
        fprintf(stderr, "NewHd, given %s, gives the exception: %s.\n",
                in.use_hd_filename.c_str(), e.GetMsg().c_str());
        delete gf;
        return Finalize(-1);
      }
    } else {
      printf("... Computing spatial decomposition.\n");
      hd = gf->ComputeHd();
      if (!in.write_hd_filename.empty())
        try {
          WriteHd(hd, in.write_hd_filename);
        } catch (const FileException& e) {
          fprintf(stderr, "Could not write %s.\n",
                  in.write_hd_filename.c_str());
          delete gf;
          return Finalize(-1);
        }
    }
  }

  // Set up Compressor.
  Compressor* c = NULL;
  if (am_root) printf("... Setting up compressor.\n");
  try {
    c = hmmvp::NewCompressor(hd, gf, in.write_hmat_filename);
    c->SetOutputLevel(1);
    c->SetTolMethod(Compressor::tm_Bfro);
    c->SetTol(in.tol);
    if (!in.use_hmat_filename.empty())
      try {
        c->UseHmatFile(in.use_hmat_filename);
      } catch (const Exception& e) {
        if (am_root)
          fprintf(stderr, "Warning: Ignoring old H-matrix file %s; received "
                  "the exception: %s.\n", in.use_hmat_filename.c_str(),
                  e.GetMsg().c_str());
      }
    SetBfro(c, in.Bfro);
  } catch (const Exception& fe) {
    if (am_root) {
      fprintf(stderr, "Exception creating Compressor: %s\n",
              fe.GetMsg().c_str());
      DeleteHd(hd);
    }
    return Finalize(-1);
  }

  if (am_root) DeleteHd(hd);

  // Compress.
  if (am_root) printf("... Compressing.\n");
  try {
    c->Compress();
  } catch (const UserReqException& e) {
    if (am_root) fprintf(stderr, "Green's function requested stop.\n");
  } catch (const Exception& e) {
    fprintf(stderr, "Compressor threw: %s\n", e.GetMsg().c_str());
  }

  DeleteCompressor(c);
  delete gf;
  return Finalize(0);
}
